// source code for W01dot1
// name: Benjamin Vredenburg
// last modified: 09/15/2021
// course: CIT-260

public class Main {

    public static void main(String[] args) {
	System.out.println("Benjamin Vredenburg");
    System.out.println("CIT 260-01");
    System.out.println("Ocean Shores, Washington");
    System.out.println("Key Lime Pie");
    }
}
