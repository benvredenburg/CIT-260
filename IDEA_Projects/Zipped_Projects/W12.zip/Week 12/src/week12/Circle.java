// source code for Circle
// name: Benjamin Vredenburg
// last modified: 11/29/2021
// course: CIT-260

package week12;

public class Circle extends GeometricObject {
    // Define data members
    private double radius = 0;

    /**
     * The no-arg constructor for Circle
     */
    public Circle() {
        radius = 0;
    }

    /**
     * the parameterized constructor for Circle
     * @param ID int
     * @param radius double
     */
    public Circle(int ID, double radius) {
        super(ID);
        this.radius = radius;
    }

    /**
     * The getter method for radius
     * @return double
     */
    public double getRadius() {
        return radius;
    }

    /**
     * Method for getArea
     * @return double
     */
    @Override
    public double getArea() {
        return Math.PI * radius * radius;
    }
}
