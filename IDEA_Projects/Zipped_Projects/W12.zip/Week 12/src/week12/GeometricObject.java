// source code for GeometricObject
// name: Benjamin Vredenburg
// last modified: 11/30/2021
// course: CIT-260

package week12;

public abstract class GeometricObject {
    // Define data members
    private int ID = 0;

    /**
     * The no-arg constructor
     */
    public GeometricObject() {
        ID = 0;
    }

    /**
     * The parameterized constructor
     * @param ID int
     */
    public GeometricObject(int ID){
        this.ID = ID;
    }

    /**
     * The getter method for ID
     * @return int
     */
    public int getID() {
        return ID;
    }

    /**
     * Method for getArea
     * @return double
     */
    public abstract double getArea();
}
