// source code for W12
// name: Benjamin Vredenburg
// last modified: 11/30/2021
// course: CIT-260

package week12;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
	// Tell user what this program does
        System.out.println("\nThis program creates takes an array of geometric objects and \ndisplays the areas " +
                "of the objects to the user");
    //Create an ArrayList<GeometricObject>
        ArrayList<GeometricObject> shapes = new ArrayList<>();

    // Create the following objects and store the references to them in a single ArrayList.
        // A Circle object with a radius of 10 inches and an ID of 156.
        // A Square object with a side of 2 inches and an ID of 237
        // a Right Triangle with a height of 3 inches, a base of 4 inches, and an ID of 212
        shapes.add(new Circle(156, 10));
        shapes.add(new Square(237, 2));
        shapes.add(new Triangle(212, 3, 4));

    // Create header for output
        System.out.println("\nIdentifier Area");

    // Iterate through the ArrayList and display the area of the three different shape objects
        // to the user
        for(int i = 0; i < shapes.size(); i++) {
            System.out.print(shapes.get(i).getID());
            System.out.printf("%14.2f", shapes.get(i).getArea());
            System.out.println(" sq. inches");
        }

    // Display a goodbye message
        System.out.println("\n\nHave a wonderful day.");
    }
}
