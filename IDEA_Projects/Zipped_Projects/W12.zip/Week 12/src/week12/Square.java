// source code for Square
// name: Benjamin Vredenburg
// last modified: 11/29/2021
// course: CIT-260

package week12;

public class Square extends GeometricObject {
    // Define data members
    private double sideSquare;

    /**
     * The no-arg constructor
     */
    public Square() {
        sideSquare = 0;
    }

    /**
     * The parameterized constructor
     * @param ID int
     * @param sideSquare double
     */
    public Square(int ID, double sideSquare) {
        super(ID);
        this.sideSquare = sideSquare;
    }

    /**
     * The getter method for sideSquare
     * @return double
     */
    public double getSideSquare() {
        return sideSquare;
    }

    /**
     * Method for getArea
     * @return double
     */
    @Override
    public double getArea() {
        return sideSquare * sideSquare;
    }
}
