// source code for Triangle
// name: Benjamin Vredenburg
// last modified: 11/29/2021
// course: CIT-260

package week12;

public class Triangle extends GeometricObject {
    // Define data members
    private double height;
    private double base;

    /**
     * The no-arg constructor
     */
    public Triangle() {
        height = 0;
        base = 0;
    }

    /**
     * The parameterized constructor
     * @param ID int
     * @param height double
     * @param base double
     */
    public Triangle(int ID, double height, double base) {
        super(ID);
        this.height = height;
        this.base = base;
    }

    /**
     * The getter method for height
     * @return double
     */
    public double getHeight() {
        return height;
    }

    /**
     * The getter method for base
     * @return double
     */
    public double getBase() {
        return base;
    }

    /**
     * Method for getArea
     * @return double
     */
    @Override
    public double getArea() {
        return (height * base) / 2;
    }
}
